import React from 'react';
import ReactDOM from 'react-dom';
import './style.css';

function App() {
  return (
    <div>
      <h1>SearchPlus AI</h1>
      <p>مرحبًا بك في أول نموذج مبدئي!</p>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
